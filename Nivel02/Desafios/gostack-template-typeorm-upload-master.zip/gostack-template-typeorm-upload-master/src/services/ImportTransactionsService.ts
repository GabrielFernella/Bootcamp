import Transaction from '../models/Transaction';

class ImportTransactionsService {
  async execute(): Promise<Transaction[]> {
    // TODO
  }
}

export default ImportTransactionsService;
