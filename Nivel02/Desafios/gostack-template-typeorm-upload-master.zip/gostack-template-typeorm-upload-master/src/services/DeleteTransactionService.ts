// import AppError from '../errors/AppError';

class DeleteTransactionService {
  public async execute(): Promise<void> {
    // TODO
  }
}

export default DeleteTransactionService;
