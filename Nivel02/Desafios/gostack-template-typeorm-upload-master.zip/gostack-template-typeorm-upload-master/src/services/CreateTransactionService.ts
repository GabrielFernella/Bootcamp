// import AppError from '../errors/AppError';

import Transaction from '../models/Transaction';

class CreateTransactionService {
  public async execute(): Promise<Transaction> {
    // TODO
  }
}

export default CreateTransactionService;
